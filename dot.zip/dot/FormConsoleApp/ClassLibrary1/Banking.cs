﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DelegateLibrary;

namespace ClassLibrary1
{
    public class Banking
    {
        public event Operations Overbalance;
        public event Operations UnderBalance;


        private double balance;
        public double Balance
        {
            get { return balance; }
            set { balance = value; }
        }

        public void Deposit(double amount)
        {
            balance = balance + amount;
            Monitor();
        }

        public void Withdraw(double amount)
        {
            balance = balance - amount;
            Monitor();

        }
        public void Monitor()
        {
            if (balance >= 50000)
            {
             balance =balance - Overbalance(500);
            }
            else if (balance <= 10000)
            {
               balance=balance- UnderBalance(1000);
            }
        }
    }
}
